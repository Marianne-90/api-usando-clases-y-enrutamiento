## Flight Tests

This directory contains unit tests for Flight. The tests were written for PHPUnit 3.7.10

To run the tests do:

    composer install
    vendor/bin/phpunit tests

Learn more about PHPUnit at [http://www.phpunit.de](http://www.phpunit.de/manual/current/en/index.html)
